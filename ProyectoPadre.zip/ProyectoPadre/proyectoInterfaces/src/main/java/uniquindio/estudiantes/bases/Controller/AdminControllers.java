package uniquindio.estudiantes.bases.Controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class AdminControllers {
	
    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtApellido;

    @FXML
    private TextField txtDocumento;

    @FXML
    private TextField txtEmail;

    @FXML
    private ComboBox<?> comboGrupoD;

    @FXML
    private ComboBox<?> comboCiudad;

    @FXML
    private TextField txtTelefono;

    @FXML
    private TextField txtNombre1;

    @FXML
    private TextField txtApellido1;

    @FXML
    private TextField txtDocumento1;

    @FXML
    private TextField txtEmail1;

    @FXML
    private ComboBox<?> comboCursoE;

    @FXML
    private ComboBox<?> comboCiudad1;

    @FXML
    private TextField txtTelefono1;

    @FXML
    private TextField txtNombreCurso;

    @FXML
    private TextField txtIntensidad;

    @FXML
    private TextArea txtDescripcionCurso;

    @FXML
    private ComboBox<?> comboEstado;

    @FXML
    private TextField txtIdCurso;

    @FXML
    private Button btnAgregarCurso;

    @FXML
    private TextField txtNombreGrupo;

    @FXML
    private TextField txtAñoGrupo;

    @FXML
    private TextField txtIdGrupo;

    @FXML
    private TextField txtCodInternoGrupo;

    @FXML
    private ComboBox<?> comboCursos;

    @FXML
    private Button btnAgregarGrupo;

}
