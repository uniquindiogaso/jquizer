package uniquindio.estudiantes.bases.Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

public class LoginControllers {

    @FXML
    private Button btnIngresar;

	@FXML
	private TextField txtPass;

	@FXML
	private TextField txtUser;

	@FXML
	private ImageView imgLogin;

	@FXML
	void validarLogin(ActionEvent event) {

	}

}
