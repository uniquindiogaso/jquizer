package uniquindio.estudiantes.bases.Controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;

public class EstudianteControllers {
	
    @FXML
    private TableView<?> tableHorario;

    @FXML
    private TableView<?> tablePresentarExamen;

    @FXML
    private Button btnAcceder;

    @FXML
    private TableView<?> tableNotas;

}
